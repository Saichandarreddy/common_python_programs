import common_python_programs
x = common_python_programs.joke()
print(x)
